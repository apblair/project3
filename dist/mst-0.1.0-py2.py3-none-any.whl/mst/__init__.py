"""
BMI203: Biocomputing algorithms Winter 2022
Assignment 3: Minimum spanning trees
"""

from .graph import Graph

__version__ = '0.1.0'
